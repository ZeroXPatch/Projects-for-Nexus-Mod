using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;
using StardewValley.GameData.Buildings;
using StardewValley.Buildings;

namespace BuildAtRobin
{
    [HarmonyPatch(typeof(CarpenterMenu))]
    internal static class CarpenterMenuPatch
    {
        private static Dictionary<string, int>? _preClickInventory;
        private static string? _cachedBuildingId;

        // Cache fields
        private static FieldInfo? _previewBuildingField;
        private static bool _searchComplete = false;

        // -----------------------------------------------------------------------
        // PATCH 1: Light up the "Build" button
        // -----------------------------------------------------------------------
        [HarmonyPatch("DoesFarmerHaveEnoughResourcesToBuild")]
        [HarmonyPrefix]
        public static bool Prefix_CheckResources(CarpenterMenu __instance, ref bool __result)
        {
            // Reset logging so we see the count in the console
            // (This runs every frame, so we rely on InventoryManager to limit spam)

            BuildingData? data = GetCurrentBuildingData(__instance);

            if (data != null)
            {
                __result = CheckHasPermissions(data);

                // If __result is true, we found enough items!
                // We return false to tell the game "Don't run your check, use ours"
                return false;
            }

            return true;
        }

        // -----------------------------------------------------------------------
        // PATCH 2: Consume resources on click
        // -----------------------------------------------------------------------
        [HarmonyPatch("receiveLeftClick")]
        [HarmonyPrefix]
        public static void Prefix_Click(CarpenterMenu __instance)
        {
            // Reset log for next check
            InventoryManager.ResetLog();

            _preClickInventory = null;
            _cachedBuildingId = null;

            BuildingData? data = GetCurrentBuildingData(__instance);
            if (data != null && data.BuildMaterials != null)
            {
                _cachedBuildingId = GetBuildingId(__instance);
                _preClickInventory = new Dictionary<string, int>();
                foreach (var mat in data.BuildMaterials)
                {
                    if (!_preClickInventory.ContainsKey(mat.ItemId))
                        _preClickInventory[mat.ItemId] = Game1.player.Items.CountId(mat.ItemId);
                }
            }
        }

        [HarmonyPatch("receiveLeftClick")]
        [HarmonyPostfix]
        public static void Postfix_Click(CarpenterMenu __instance)
        {
            if (_preClickInventory == null || _cachedBuildingId == null) return;

            if (Game1.buildingData.TryGetValue(_cachedBuildingId, out BuildingData? data) && data.BuildMaterials != null)
            {
                foreach (var mat in data.BuildMaterials)
                {
                    string itemId = mat.ItemId;
                    int required = mat.Amount;

                    if (_preClickInventory.TryGetValue(itemId, out int startCount))
                    {
                        int currentCount = Game1.player.Items.CountId(itemId);
                        int vanillaTook = startCount - currentCount;
                        int remaining = required - vanillaTook;

                        if (remaining > 0)
                        {
                            InventoryManager.ConsumeItemsFromChests(itemId, remaining);
                        }
                    }
                }
            }

            _preClickInventory = null;
            _cachedBuildingId = null;
        }

        // --- Helper Logic ---

        private static string? GetBuildingId(CarpenterMenu menu)
        {
            try
            {
                // 1. Try public field 'building' (Standard 1.6)
                var publicField = typeof(CarpenterMenu).GetField("building", BindingFlags.Instance | BindingFlags.Public);
                if (publicField != null)
                {
                    if (publicField.GetValue(menu) is Building b) return b.buildingType.Value;
                }

                // 2. Dynamic Search (Fallback)
                if (!_searchComplete)
                {
                    var fields = typeof(CarpenterMenu).GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    foreach (var field in fields)
                    {
                        if (typeof(Building).IsAssignableFrom(field.FieldType))
                        {
                            _previewBuildingField = field;
                            break;
                        }
                    }
                    _searchComplete = true;
                }

                if (_previewBuildingField != null)
                {
                    if (_previewBuildingField.GetValue(menu) is Building preview) return preview.buildingType.Value;
                }
            }
            catch (Exception ex)
            {
                ModEntry.ModMonitor.LogOnce($"[BuildAtRobin] Error finding building: {ex.Message}", LogLevel.Error);
            }
            return null;
        }

        private static BuildingData? GetCurrentBuildingData(CarpenterMenu menu)
        {
            string? id = GetBuildingId(menu);
            if (id != null && Game1.buildingData.TryGetValue(id, out BuildingData? data))
            {
                return data;
            }
            return null;
        }

        private static bool CheckHasPermissions(BuildingData data)
        {
            if (data.BuildCost > Game1.player.Money) return false;

            if (data.BuildMaterials != null)
            {
                foreach (var mat in data.BuildMaterials)
                {
                    int total = InventoryManager.CountItems(mat.ItemId);
                    if (total < mat.Amount)
                    {
                        // Log failure for debugging
                        // ModEntry.ModMonitor.LogOnce($"[BuildAtRobin] Missing {mat.ItemId}: Need {mat.Amount}, Found {total}", LogLevel.Warn);
                        return false;
                    }
                }
            }
            return true;
        }
    }
}