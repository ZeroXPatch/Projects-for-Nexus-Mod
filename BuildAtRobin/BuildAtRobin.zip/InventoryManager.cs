using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Buildings;
using StardewValley.Inventories;
using StardewValley.Locations;
using StardewValley.Objects;

namespace BuildAtRobin
{
    internal static class InventoryManager
    {
        private const string AutoGrabberId = "(BC)165";
        private static bool _hasLoggedChests = false;

        public static int CountItems(string itemId)
        {
            // 1. Count Inventory
            int count = Game1.player.Items.CountId(itemId);

            // 2. Count Chests
            int chestCount = 0;
            int chestsFound = 0;

            foreach (var chest in GetAllChests())
            {
                chestsFound++;
                if (chest.Items != null)
                {
                    chestCount += chest.Items.CountId(itemId);
                }
            }

            // DEBUG LOG: Only print once per menu open to avoid spamming
            if (!_hasLoggedChests)
            {
                ModEntry.ModMonitor.Log($"[BuildAtRobin] Scanned {chestsFound} containers. Found {chestCount} of {itemId} in chests.", LogLevel.Trace);
                _hasLoggedChests = true; // Reset this in the MenuPatch when menu opens
            }

            return count + chestCount;
        }

        public static void ResetLog()
        {
            _hasLoggedChests = false;
        }

        public static void ConsumeItems(string itemId, int amount)
        {
            // 1. Take from Inventory
            int inInventory = Game1.player.Items.CountId(itemId);
            int takeFromInv = Math.Min(inInventory, amount);

            if (takeFromInv > 0)
            {
                Game1.player.Items.ReduceId(itemId, takeFromInv);
                amount -= takeFromInv;
            }

            if (amount <= 0) return;

            // 2. Take remaining from Chests
            ConsumeItemsFromChests(itemId, amount);
        }

        public static void ConsumeItemsFromChests(string itemId, int amount)
        {
            foreach (var chest in GetAllChests())
            {
                if (chest.Items == null) continue;

                int inChest = chest.Items.CountId(itemId);
                if (inChest > 0)
                {
                    int take = Math.Min(inChest, amount);
                    chest.Items.ReduceId(itemId, take);
                    amount -= take;

                    if (amount <= 0) break;
                }
            }
        }

        private static IEnumerable<Chest> GetAllChests()
        {
            foreach (GameLocation location in Game1.locations)
            {
                // Objects (Chests, Big Chests, Stone Chests, Auto-Grabbers)
                foreach (StardewValley.Object obj in location.objects.Values)
                {
                    if (obj is Chest chest && chest.playerChest.Value)
                    {
                        yield return chest;
                    }
                    else if (obj.QualifiedItemId == AutoGrabberId && obj.heldObject.Value is Chest grabber)
                    {
                        yield return grabber;
                    }
                }

                // Buildings (Junimo Huts, Mills)
                foreach (Building building in location.buildings)
                {
                    if (building is JunimoHut hut)
                        yield return hut.GetOutputChest();
                    else
                    {
                        Chest? output = building.GetBuildingChest("Output");
                        if (output != null) yield return output;
                    }
                }

                // Fridges
                if (location is FarmHouse fh && fh.fridge.Value != null && fh.fridgePosition != Point.Zero)
                    yield return fh.fridge.Value;
                if (location is IslandFarmHouse ifh && ifh.fridge.Value != null)
                    yield return ifh.fridge.Value;
            }
        }
    }
}