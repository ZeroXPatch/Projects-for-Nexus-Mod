using System.Collections.Generic;
using System.Linq;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Inventories; // Required for 1.6
using StardewValley.Menus;
using StardewValley.Objects;

namespace CraftAnywhere
{
    internal class ModEntry : Mod
    {
        private ChestScanner? Scanner;

        // Caching variables to prevent scanning every single tick
        private IClickableMenu? LastInjectedMenu;
        private int LastTabId = -1;

        public override void Entry(IModHelper helper)
        {
            this.Scanner = new ChestScanner();

            helper.Events.Display.MenuChanged += this.OnMenuChanged;
            helper.Events.GameLoop.UpdateTicked += this.OnUpdateTicked;
        }

        /// <summary>
        /// Triggered when the active menu changes (e.g., opening a Workbench or the main menu).
        /// </summary>
        private void OnMenuChanged(object? sender, MenuChangedEventArgs e)
        {
            this.LastInjectedMenu = null;
            this.LastTabId = -1;

            // Case 1: Opened a Workbench or direct crafting menu
            if (e.NewMenu is CraftingPage craftingPage)
            {
                this.InjectChests(craftingPage);
            }
            // Case 2: Opened the Game Menu (E), need to check if it started on the Crafting tab
            else if (e.NewMenu is GameMenu gameMenu && gameMenu.currentTab == GameMenu.craftingTab)
            {
                if (gameMenu.GetCurrentPage() is CraftingPage page)
                {
                    this.InjectChests(page);
                }
            }
        }

        /// <summary>
        /// Checks for tab switching (e.g., Inventory -> Crafting) which doesn't trigger MenuChanged.
        /// </summary>
        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady) return;

            if (Game1.activeClickableMenu is GameMenu gameMenu)
            {
                // Only run logic if the tab changed to Crafting
                if (gameMenu.currentTab == GameMenu.craftingTab &&
                   (gameMenu.currentTab != this.LastTabId || this.LastInjectedMenu != gameMenu))
                {
                    if (gameMenu.GetCurrentPage() is CraftingPage page)
                    {
                        this.InjectChests(page);
                    }
                }

                this.LastTabId = gameMenu.currentTab;
            }
        }

        /// <summary>
        /// Injects all world chests into the crafting menu.
        /// </summary>
        private void InjectChests(CraftingPage page)
        {
            this.LastInjectedMenu = Game1.activeClickableMenu ?? page;

            // 1. Scan the world (Heavy operation, done only once per menu view)
            // Scanner returns List<Chest>
            List<Chest> globalChests = this.Scanner!.GetAllChests();

            if (globalChests.Count == 0) return;

            // 2. Access the private list vanilla uses for Workbench memory
            // FIX: In 1.6, this field is List<IInventory>, not List<Chest>
            var containersField = this.Helper.Reflection.GetField<List<IInventory>>(page, "_materialContainers");
            List<IInventory> currentContainers = containersField.GetValue();

            // 3. Initialize if null (Vanilla often leaves this null if not at a Workbench)
            if (currentContainers == null)
            {
                currentContainers = new List<IInventory>();
                containersField.SetValue(currentContainers);
            }

            // 4. Update the list safely
            // We must convert the Chests to IInventory objects
            currentContainers.Clear();
            foreach (Chest chest in globalChests)
            {
                // GetItemsForPlayer handles mutexes and getting the actual item list
                var inventory = chest.GetItemsForPlayer(Game1.player.UniqueMultiplayerID);
                if (inventory != null)
                {
                    currentContainers.Add(inventory);
                }
            }
        }
    }
}