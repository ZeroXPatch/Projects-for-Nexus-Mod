using System.Collections.Generic;
using Microsoft.Xna.Framework;
using StardewValley;
using StardewValley.Buildings;
using StardewValley.Locations;
using StardewValley.Objects;

namespace CraftAnywhere
{
    internal class ChestScanner
    {
        // Qualified Item ID for Auto-Grabbers
        private const string AutoGrabberId = "(BC)165";

        /// <summary>
        /// Scans the entire world for accessible chests and storage units.
        /// </summary>
        public List<Chest> GetAllChests()
        {
            List<Chest> foundChests = new List<Chest>();

            // Iterate all locations (efficient 1.6+ method)
            foreach (GameLocation location in Game1.locations)
            {
                // 1. Scan Objects (Chests, Auto-Grabbers)
                foreach (StardewValley.Object obj in location.objects.Values)
                {
                    // Player Chests (Standard, Stone, Big, etc.)
                    if (obj is Chest chest && chest.playerChest.Value)
                    {
                        foundChests.Add(chest);
                    }
                    // Auto-Grabbers
                    else if (obj.QualifiedItemId == AutoGrabberId && obj.heldObject.Value is Chest grabberChest)
                    {
                        foundChests.Add(grabberChest);
                    }
                }

                // 2. Scan Buildings (Mills, Junimo Huts, Sheds are just locations so they are covered above)
                foreach (Building building in location.buildings)
                {
                    if (building is JunimoHut hut)
                    {
                        foundChests.Add(hut.GetOutputChest());
                    }
                    else
                    {
                        // Generic check for any building with an "Output" chest (e.g. Mill)
                        Chest? output = building.GetBuildingChest("Output");
                        if (output != null)
                        {
                            foundChests.Add(output);
                        }
                    }
                }

                // 3. Scan Fridges
                if (location is FarmHouse house)
                {
                    if (house.fridge.Value != null && house.fridgePosition != Point.Zero)
                    {
                        foundChests.Add(house.fridge.Value);
                    }
                }
                else if (location is IslandFarmHouse islandHouse)
                {
                    if (islandHouse.fridge.Value != null)
                    {
                        foundChests.Add(islandHouse.fridge.Value);
                    }
                }
            }

            return foundChests;
        }
    }
}