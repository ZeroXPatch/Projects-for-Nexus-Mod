﻿namespace AutoFillPetBowl;

public class ModConfig
{
    public bool Enabled { get; set; } = true;
    public bool EnableLogging { get; set; } = false;
}