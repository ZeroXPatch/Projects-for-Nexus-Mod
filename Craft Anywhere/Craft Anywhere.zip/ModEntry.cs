using System;
using System.Collections.Generic;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Inventories;
using StardewValley.Menus;
using StardewValley.Objects;

namespace CraftAnywhere
{
    internal class ModEntry : Mod
    {
        private ChestScanner? Scanner;

        // Caching variables
        private IClickableMenu? LastInjectedMenu;
        private int LastTabId = -1;

        public override void Entry(IModHelper helper)
        {
            this.Scanner = new ChestScanner();

            helper.Events.Display.MenuChanged += this.OnMenuChanged;
            helper.Events.GameLoop.UpdateTicked += this.OnUpdateTicked;
        }

        private void OnMenuChanged(object? sender, MenuChangedEventArgs e)
        {
            this.LastInjectedMenu = null;
            this.LastTabId = -1;

            if (e.NewMenu is CraftingPage craftingPage)
            {
                this.InjectChests(craftingPage);
            }
            else if (e.NewMenu is GameMenu gameMenu && gameMenu.currentTab == GameMenu.craftingTab)
            {
                if (gameMenu.GetCurrentPage() is CraftingPage page)
                {
                    this.InjectChests(page);
                }
            }
        }

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady) return;

            if (Game1.activeClickableMenu is GameMenu gameMenu)
            {
                if (gameMenu.currentTab == GameMenu.craftingTab &&
                   (gameMenu.currentTab != this.LastTabId || this.LastInjectedMenu != gameMenu))
                {
                    if (gameMenu.GetCurrentPage() is CraftingPage page)
                    {
                        this.InjectChests(page);
                    }
                }
                this.LastTabId = gameMenu.currentTab;
            }
        }

        private void InjectChests(CraftingPage page)
        {
            this.LastInjectedMenu = Game1.activeClickableMenu ?? page;

            // 1. Scan the world
            List<Chest> globalChests = this.Scanner!.GetAllChests();

            if (globalChests.Count == 0) return;

            // Debug log to help users identify if chests are found (prints to SMAPI console)
            // This is useful for the bug report to verify if the scanner sees the Big Chests.
            this.Monitor.Log($"Found {globalChests.Count} global containers.", LogLevel.Trace);

            // 2. Access the private list vanilla uses for Workbench memory
            var containersField = this.Helper.Reflection.GetField<List<IInventory>>(page, "_materialContainers");
            List<IInventory> currentContainers = containersField.GetValue();

            // 3. Initialize if null
            if (currentContainers == null)
            {
                currentContainers = new List<IInventory>();
                containersField.SetValue(currentContainers);
            }

            // 4. Update the list
            currentContainers.Clear();
            foreach (Chest chest in globalChests)
            {
                // FIX FOR BUG REPORT:
                // Instead of chest.GetItemsForPlayer(...) which checks for locks/mutexes 
                // and might fail with "Unlimited Storage" or other mods,
                // we access chest.Items directly. In 1.6, chest.Items is the IInventory.
                try
                {
                    if (chest.Items != null)
                    {
                        currentContainers.Add(chest.Items);
                    }
                }
                catch (Exception ex)
                {
                    // Fallback in case a mod completely broke the Items property
                    this.Monitor.LogOnce($"Failed to access inventory for a chest at {chest.TileLocation}: {ex.Message}", LogLevel.Warn);
                }
            }
        }
    }
}