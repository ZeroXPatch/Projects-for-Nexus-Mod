# Sleep Buffs - Translation Guide

## File Structure

To use translations in your mod, create an `i18n` folder in your mod directory with the following structure:

```
SleepBuffs/
├── i18n/
│   ├── default.json (English - required)
│   ├── es.json (Spanish - optional)
│   ├── fr.json (French - optional)
│   ├── de.json (German - optional)
│   ├── pt.json (Portuguese - optional)
│   ├── ru.json (Russian - optional)
│   ├── zh.json (Chinese - optional)
│   ├── ja.json (Japanese - optional)
│   └── ko.json (Korean - optional)
├── ModEntry.cs
├── ModConfig.cs
├── IGenericModConfigMenuApi.cs
├── manifest.json
└── SleepBuffs.csproj
```

## Translation Keys

All translatable strings are now in the `default.json` file. Copy this file and rename it to the appropriate language code to create translations for other languages.

### Available Keys:

- **Config Menu:**
  - `config.enableDebuffs.name` - Name of the config option
  - `config.enableDebuffs.tooltip` - Tooltip description

- **HUD Messages:**
  - `message.wellRested` - Message shown when well rested
  - `message.sleepDeprived` - Message shown when sleep deprived

- **Buff Names:**
  - `buff.wellRested.name` - Well Rested buff title
  - `buff.sleepDeprived.name` - Sleep Deprived debuff title

- **Buff Descriptions:**
  - `buff.wellRested.description` - Description with `{{stats}}` placeholder
  - `buff.sleepDeprived.description` - Description with `{{stats}}` placeholder

- **Stat Names:**
  - `stat.farming` through `stat.maxstamina` - Individual stat names

## Creating New Translations

1. Copy `default.json`
2. Rename to the appropriate language code (e.g., `es.json` for Spanish)
3. Translate all the values (keep the keys the same)
4. The `{{stats}}` placeholder will be automatically replaced with translated stat names

## Example Spanish Translation (es.json)

```json
{
  "config.enableDebuffs.name": "Habilitar Penalizaciones de Sueño",
  "config.enableDebuffs.tooltip": "Si está habilitado, dormir menos de 6 horas (después de las 12:00 AM) dará estadísticas negativas aleatorias.",
  
  "message.wellRested": "¡Te sientes bien descansado!",
  "message.sleepDeprived": "No dormiste lo suficiente...",
  
  "buff.wellRested.name": "Bien Descansado",
  "buff.wellRested.description": "Energizado: {{stats}} aumentadas.",
  
  "buff.sleepDeprived.name": "Privado de Sueño",
  "buff.sleepDeprived.description": "Aturdido: {{stats}} reducidas.",
  
  "stat.farming": "Agricultura",
  "stat.fishing": "Pesca",
  "stat.mining": "Minería",
  "stat.combat": "Combate",
  "stat.foraging": "Recolección",
  "stat.luck": "Suerte",
  "stat.speed": "Velocidad",
  "stat.defense": "Defensa",
  "stat.attack": "Ataque",
  "stat.maxstamina": "Energía Máxima"
}
```
