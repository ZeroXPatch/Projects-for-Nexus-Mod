using System;
using StardewModdingAPI;
using StardewModdingAPI.Utilities;

namespace AutoFishingMaster
{
    public interface IGenericModConfigMenuApi
    {
        // Fixed: Used 'IManifest' instead of 'IModManifest'
        void Register(IManifest mod, Action reset, Action save, bool titleScreenOnly = false);
        void AddSectionTitle(IManifest mod, Func<string> text, Func<string> tooltip = null);
        void AddBoolOption(IManifest mod, Func<bool> getValue, Action<bool> setValue, Func<string> name, Func<string> tooltip = null, string fieldId = null);
        void AddKeybind(IManifest mod, Func<SButton> getValue, Action<SButton> setValue, Func<string> name, Func<string> tooltip = null, string fieldId = null);
    }
}