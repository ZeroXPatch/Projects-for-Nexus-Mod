﻿namespace TrashCanExpanded
{
    public class ModConfig
    {
        public bool Enabled { get; set; } = true;

        // Daily Chances (0.01 = 1%)
        public float ChanceMonday { get; set; } = 0.01f;
        public float ChanceTuesday { get; set; } = 0.02f;
        public float ChanceWednesday { get; set; } = 0.03f;
        public float ChanceThursday { get; set; } = 0.04f;
        public float ChanceFriday { get; set; } = 0.05f;
        public float ChanceSaturday { get; set; } = 0.10f;
        public float ChanceSunday { get; set; } = 0.20f; // 20% on Sundays

        public int MaxItemValue { get; set; } = 500;
    }
}