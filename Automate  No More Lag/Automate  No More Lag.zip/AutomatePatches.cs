using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using StardewValley;
using Microsoft.Xna.Framework;

namespace ZeroXPatch
{
    /// <summary>Harmony patches for Automate mod.</summary>
    internal static class AutomatePatches
    {
        private static long updateCyclesChecked = 0;
        private static long updateCyclesSkipped = 0;
        private static long updateCyclesProcessed = 0;

        // Idle detection tracking
        private static Vector2 lastPlayerPosition = Vector2.Zero;
        private static int ticksSinceLastMove = 0;
        private static bool isPlayerIdle = false;

        /// <summary>Apply all Harmony patches.</summary>
        public static void Apply(Harmony harmony)
        {
            try
            {
                // Find Automate's assembly
                var automateAssembly = AppDomain.CurrentDomain.GetAssemblies()
                    .FirstOrDefault(a => a.GetName().Name == "Automate");

                if (automateAssembly == null)
                {
                    ModEntry.ModMonitor.Log("Could not find Automate assembly", StardewModdingAPI.LogLevel.Warn);
                    return;
                }

                // PATCH AT THE HIGHEST LEVEL - MachineManager.AutomateAll()
                // This stops Automate from even iterating through machine groups
                var machineManagerType = automateAssembly.GetType("Pathoschild.Stardew.Automate.Framework.MachineManager");
                if (machineManagerType != null)
                {
                    // Try to find the automation method - it might be called different things in different versions
                    MethodInfo automateAllMethod = null;

                    // Try common method names
                    string[] possibleMethodNames = { "AutomateAll", "Automate", "OnUpdateTicked" };
                    foreach (var methodName in possibleMethodNames)
                    {
                        automateAllMethod = machineManagerType.GetMethod(methodName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                        if (automateAllMethod != null)
                        {
                            ModEntry.ModMonitor.Log($"Found automation method: {methodName}", StardewModdingAPI.LogLevel.Debug);
                            break;
                        }
                    }

                    if (automateAllMethod != null)
                    {
                        harmony.Patch(
                            original: automateAllMethod,
                            prefix: new HarmonyMethod(typeof(AutomatePatches), nameof(MachineManagerAutomatePrefix))
                        );
                        ModEntry.ModMonitor.Log($"Successfully patched MachineManager at the top level for ZERO overhead!", StardewModdingAPI.LogLevel.Info);
                    }
                    else
                    {
                        ModEntry.ModMonitor.Log("Could not find MachineManager automation method - trying fallback patch", StardewModdingAPI.LogLevel.Warn);

                        // FALLBACK: Patch MachineGroup.Automate if we can't find the manager method
                        var machineGroupType = automateAssembly.GetType("Pathoschild.Stardew.Automate.Framework.MachineGroup");
                        if (machineGroupType != null)
                        {
                            var automateGroupMethod = machineGroupType.GetMethod("Automate", BindingFlags.Public | BindingFlags.Instance);
                            if (automateGroupMethod != null)
                            {
                                harmony.Patch(
                                    original: automateGroupMethod,
                                    prefix: new HarmonyMethod(typeof(AutomatePatches), nameof(MachineGroupAutomatePrefix))
                                );
                                ModEntry.ModMonitor.Log("Applied fallback patch to MachineGroup.Automate", StardewModdingAPI.LogLevel.Info);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ModEntry.ModMonitor.Log($"Error in Apply patches: {ex}", StardewModdingAPI.LogLevel.Error);
            }
        }

        /// <summary>Check if player is in a cutscene, event, or dialogue.</summary>
        private static bool IsPlayerInCutsceneOrDialogue()
        {
            if (Game1.player == null) return false;

            // Check if in event/cutscene
            if (Game1.eventUp || Game1.CurrentEvent != null)
                return true;

            // Check if in dialogue
            if (Game1.activeClickableMenu != null)
            {
                var menuType = Game1.activeClickableMenu.GetType().Name;
                // DialogueBox is the main dialogue menu
                if (menuType == "DialogueBox")
                    return true;
            }

            // Check if currently talking to someone
            if (Game1.player.currentLocation?.currentEvent != null)
                return true;

            // Additional check for any NPC dialogue
            if (Game1.currentSpeaker != null)
                return true;

            return false;
        }

        /// <summary>Update idle detection tracking.</summary>
        public static void UpdateIdleDetection()
        {
            if (!ModEntry.Config.OnlyProcessWhenIdle)
            {
                isPlayerIdle = true; // Always consider idle if feature is disabled
                return;
            }

            if (Game1.player == null)
            {
                return;
            }

            // Check if player is in cutscene/event/dialogue
            bool inCutsceneOrDialogue = IsPlayerInCutsceneOrDialogue();

            // If player is in cutscene/dialogue and option is enabled, don't count idle time
            if (ModEntry.Config.PauseTimerDuringCutscenes && inCutsceneOrDialogue)
            {
                // Don't reset the timer, just don't increment it
                // This preserves any idle time already accumulated
                if (ModEntry.Config.DebugMode && ticksSinceLastMove > 0)
                {
                    ModEntry.ModMonitor.Log($"[DEBUG] In cutscene/dialogue - idle timer paused at {ticksSinceLastMove} ticks", StardewModdingAPI.LogLevel.Trace);
                }
                return;
            }

            Vector2 currentPosition = Game1.player.Position;

            // Check if player has moved
            if (currentPosition != lastPlayerPosition)
            {
                // Player moved - reset idle counter
                ticksSinceLastMove = 0;
                isPlayerIdle = false;
                lastPlayerPosition = currentPosition;

                if (ModEntry.Config.DebugMode)
                {
                    ModEntry.ModMonitor.Log($"[DEBUG] Player moved - resetting idle timer", StardewModdingAPI.LogLevel.Trace);
                }
            }
            else
            {
                // Player hasn't moved - increment counter
                ticksSinceLastMove++;

                // Check if player has been idle long enough
                if (!isPlayerIdle && ticksSinceLastMove >= ModEntry.Config.IdleTicksThreshold)
                {
                    isPlayerIdle = true;

                    if (ModEntry.Config.DebugMode)
                    {
                        ModEntry.ModMonitor.Log($"[DEBUG] Player is now IDLE (after {ticksSinceLastMove} ticks)", StardewModdingAPI.LogLevel.Debug);
                    }
                }
            }
        }

        /// <summary>Get whether the player is currently considered idle.</summary>
        public static bool IsPlayerIdle()
        {
            return isPlayerIdle;
        }

        /// <summary>
        /// Prefix for MachineManager automation methods.
        /// This stops ALL Automate processing before it even starts iterating through machine groups.
        /// ZERO OVERHEAD when player is moving!
        /// </summary>
        private static bool MachineManagerAutomatePrefix()
        {
            try
            {
                updateCyclesChecked++;

                // Check idle state (if enabled)
                if (ModEntry.Config.OnlyProcessWhenIdle && !isPlayerIdle)
                {
                    updateCyclesSkipped++;

                    if (ModEntry.Config.DebugMode && updateCyclesSkipped % 60 == 0) // Log every 60 skips to avoid spam
                    {
                        ModEntry.ModMonitor.Log($"[DEBUG] ⏸️ AUTOMATE FULLY STOPPED - Player is moving (skipped {updateCyclesSkipped} cycles)", StardewModdingAPI.LogLevel.Trace);
                    }

                    return false; // Stop Automate completely - don't even iterate through groups
                }

                // Player is idle (or feature disabled) - let Automate run normally
                updateCyclesProcessed++;

                if (ModEntry.Config.DebugMode && updateCyclesProcessed == 1)
                {
                    ModEntry.ModMonitor.Log($"[DEBUG] ✅ AUTOMATE RUNNING - Player is idle", StardewModdingAPI.LogLevel.Debug);
                }

                return true; // Let Automate run
            }
            catch (Exception ex)
            {
                ModEntry.ModMonitor.Log($"Error in MachineManagerAutomatePrefix: {ex}", StardewModdingAPI.LogLevel.Error);
                return true; // Fail safely - let Automate run normally
            }
        }

        /// <summary>
        /// FALLBACK PREFIX for MachineGroup.Automate (only used if manager patch fails).
        /// This is less efficient but still works.
        /// </summary>
        private static bool MachineGroupAutomatePrefix(object __instance)
        {
            try
            {
                updateCyclesChecked++;

                // Check idle state (if enabled)
                if (ModEntry.Config.OnlyProcessWhenIdle && !isPlayerIdle)
                {
                    updateCyclesSkipped++;

                    if (ModEntry.Config.DebugMode)
                    {
                        ModEntry.ModMonitor.Log($"[DEBUG] ⏸️ SKIPPED - Player is not idle (using fallback patch)", StardewModdingAPI.LogLevel.Trace);
                    }

                    return false; // Skip - player is moving
                }

                // Player is idle (or feature disabled) - process it
                updateCyclesProcessed++;

                if (ModEntry.Config.DebugMode)
                {
                    ModEntry.ModMonitor.Log($"[DEBUG] ✅ PROCESSING", StardewModdingAPI.LogLevel.Trace);
                }

                return true;
            }
            catch (Exception ex)
            {
                ModEntry.ModMonitor.Log($"Error in MachineGroupAutomatePrefix: {ex}", StardewModdingAPI.LogLevel.Error);
                return true; // Fail safely - let Automate process normally
            }
        }

        /// <summary>Get statistics for logging.</summary>
        public static void LogStatistics()
        {
            if (updateCyclesChecked == 0) return;

            var skipRate = (updateCyclesSkipped / (double)updateCyclesChecked) * 100;

            ModEntry.ModMonitor.Log($"=== Automate No More Lag - Statistics ===", StardewModdingAPI.LogLevel.Info);
            ModEntry.ModMonitor.Log($"Automate Cycles Checked: {updateCyclesChecked}", StardewModdingAPI.LogLevel.Info);
            ModEntry.ModMonitor.Log($"Automate Cycles Processed: {updateCyclesProcessed}", StardewModdingAPI.LogLevel.Info);
            ModEntry.ModMonitor.Log($"Automate Cycles FULLY STOPPED: {updateCyclesSkipped} ({skipRate:F1}%)", StardewModdingAPI.LogLevel.Info);

            if (ModEntry.Config.OnlyProcessWhenIdle)
            {
                string idleStatus = isPlayerIdle ? "IDLE ✅" : "MOVING 🏃";
                bool inCutscene = IsPlayerInCutsceneOrDialogue();

                if (inCutscene && ModEntry.Config.PauseTimerDuringCutscenes)
                {
                    idleStatus += " (In cutscene/dialogue - timer paused)";
                }

                ModEntry.ModMonitor.Log($"Player Idle Status: {idleStatus} (Ticks since move: {ticksSinceLastMove})", StardewModdingAPI.LogLevel.Info);
                ModEntry.ModMonitor.Log($"Performance Mode: ZERO OVERHEAD when moving!", StardewModdingAPI.LogLevel.Info);
            }

            ModEntry.ModMonitor.Log($"==========================================", StardewModdingAPI.LogLevel.Info);
        }

        /// <summary>Reset statistics.</summary>
        public static void ResetStatistics()
        {
            updateCyclesChecked = 0;
            updateCyclesSkipped = 0;
            updateCyclesProcessed = 0;
            ticksSinceLastMove = 0;
            isPlayerIdle = false;
            lastPlayerPosition = Vector2.Zero;
        }
    }
}