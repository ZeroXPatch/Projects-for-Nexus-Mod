﻿namespace CinematicWake
{
    public class ModConfig
    {
        public float WakeUpDuration { get; set; } = 4.5f; // Defaulted to 4s as requested
        public string SelectedPreset { get; set; } = "Realistic Slate";

        public int CustomRed { get; set; } = 175;
        public int CustomGreen { get; set; } = 185;
        public int CustomBlue { get; set; } = 200;
    }
}