using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;

namespace CinematicWake
{
    public class ModEntry : Mod
    {
        private ModConfig Config = null!;
        private float FadeTimer = 0f;
        private bool IsWaking = false;

        public override void Entry(IModHelper helper)
        {
            Config = helper.ReadConfig<ModConfig>();

            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
            helper.Events.GameLoop.DayStarted += OnDayStarted;
            helper.Events.GameLoop.UpdateTicked += OnUpdateTicked;
            helper.Events.Display.RenderedHud += OnRenderedHud;
        }

        private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
        {
            var configMenu = Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
            if (configMenu is null) return;

            configMenu.Register(ModManifest, () => Config = new ModConfig(), () => Helper.WriteConfig(Config));

            configMenu.AddSectionTitle(ModManifest, () => Helper.Translation.Get("morning-section"));

            // Duration Slider
            configMenu.AddNumberOption(ModManifest, () => Config.WakeUpDuration, (val) => Config.WakeUpDuration = val, () => Helper.Translation.Get("morning-duration"), min: 0.5f, max: 10f);

            // Preset Dropdown
            configMenu.AddTextOption(
                ModManifest,
                () => Config.SelectedPreset,
                (val) => Config.SelectedPreset = val,
                () => Helper.Translation.Get("morning-preset"),
                options: new string[] { "Realistic Slate", "Golden Morning", "Blue Hour", "Custom" }
            );

            // Custom RGB Section
            configMenu.AddSectionTitle(ModManifest, () => Helper.Translation.Get("morning-custom-header"));
            configMenu.AddNumberOption(ModManifest, () => Config.CustomRed, (val) => Config.CustomRed = val, () => Helper.Translation.Get("morning-red"), min: 0, max: 255);
            configMenu.AddNumberOption(ModManifest, () => Config.CustomGreen, (val) => Config.CustomGreen = val, () => Helper.Translation.Get("morning-green"), min: 0, max: 255);
            configMenu.AddNumberOption(ModManifest, () => Config.CustomBlue, (val) => Config.CustomBlue = val, () => Helper.Translation.Get("morning-blue"), min: 0, max: 255);
        }

        private void OnDayStarted(object? sender, DayStartedEventArgs e)
        {
            IsWaking = true;
            FadeTimer = Config.WakeUpDuration;
        }

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady || !IsWaking) return;

            FadeTimer -= (float)Game1.currentGameTime.ElapsedGameTime.TotalSeconds;
            if (FadeTimer <= 0) IsWaking = false;
        }

        private void OnRenderedHud(object? sender, RenderedHudEventArgs e)
        {
            if (!IsWaking || Game1.eventUp) return;

            // 1. Get linear progress (1.0 down to 0.0)
            float linearProgress = MathHelper.Clamp(FadeTimer / Config.WakeUpDuration, 0, 1);

            // 2. Apply Quadratic Easing (Progress^2)
            // This creates the "Heavy Eyes" effect where it starts dark and clears quickly.
            float easeAlpha = (float)Math.Pow(linearProgress, 2);

            Color fadeColor = GetCurrentColor();

            e.SpriteBatch.Draw(
                Game1.staminaRect,
                new Rectangle(0, 0, Game1.uiViewport.Width, Game1.uiViewport.Height),
                fadeColor * easeAlpha
            );
        }

        private Color GetCurrentColor()
        {
            return Config.SelectedPreset switch
            {
                "Realistic Slate" => new Color(175, 185, 200),
                "Golden Morning" => new Color(255, 210, 150),
                "Blue Hour" => new Color(100, 150, 255),
                "Custom" => new Color(Config.CustomRed, Config.CustomGreen, Config.CustomBlue),
                _ => new Color(175, 185, 200)
            };
        }
    }

    // Full 1.6 compatible interface to prevent "Unhandled proxy" errors
    public interface IGenericModConfigMenuApi
    {
        void Register(IManifest mod, Action reset, Action save, bool titleScreenOnly = false);
        void AddSectionTitle(IManifest mod, Func<string> text, Func<string>? tooltip = null);
        void AddTextOption(IManifest mod, Func<string> getValue, Action<string> setValue, Func<string> name, Func<string>? tooltip = null, string[]? options = null, Func<string, string>? formatAllowedValue = null, string? fieldId = null);
        void AddNumberOption(IManifest mod, Func<float> getValue, Action<float> setValue, Func<string> name, Func<string>? tooltip = null, float? min = null, float? max = null, float? interval = null, Func<float, string>? formatValue = null, string? fieldId = null);
        void AddNumberOption(IManifest mod, Func<int> getValue, Action<int> setValue, Func<string> name, Func<string>? tooltip = null, int? min = null, int? max = null, int? interval = null, Func<int, string>? formatValue = null, string? fieldId = null);
    }
}