using StardewModdingAPI;

namespace TextureCachePurge
{
    public class ModConfig
    {
        public bool AutoClearAtSleep { get; set; } = true;
        public SButton ManualClearKey { get; set; } = SButton.O;

        // RAM Threshold Settings
        // Disabled by default to avoid conflict with Stardew Stabilizer
        public bool EnableRamThreshold { get; set; } = false;
        public int RamThresholdMB { get; set; } = 2048;
    }
}