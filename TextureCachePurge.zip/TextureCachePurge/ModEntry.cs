using System;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;

namespace TextureCachePurge
{
    public class ModEntry : Mod
    {
        private ModConfig Config = null!;
        private int TicksSinceLastRamCheck = 0;
        private int CooldownTicks = 0;

        public override void Entry(IModHelper helper)
        {
            this.Config = helper.ReadConfig<ModConfig>();

            helper.Events.GameLoop.GameLaunched += this.OnGameLaunched;
            helper.Events.Input.ButtonPressed += this.OnButtonPressed;
            helper.Events.GameLoop.DayEnding += this.OnDayEnding;
            helper.Events.GameLoop.UpdateTicked += this.OnUpdateTicked;
        }

        private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
        {
            var configMenu = this.Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
            if (configMenu is null) return;

            configMenu.Register(
                mod: this.ModManifest,
                reset: () => this.Config = new ModConfig(),
                save: () => this.Helper.WriteConfig(this.Config)
            );

            // Basic Settings
            configMenu.AddBoolOption(
                this.ModManifest,
                () => this.Config.AutoClearAtSleep,
                v => this.Config.AutoClearAtSleep = v,
                () => this.Helper.Translation.Get("config.auto-sleep.name"),
                () => this.Helper.Translation.Get("config.auto-sleep.description")
            );

            configMenu.AddKeybind(
                this.ModManifest,
                () => this.Config.ManualClearKey,
                v => this.Config.ManualClearKey = v,
                () => this.Helper.Translation.Get("config.manual-key.name"),
                () => this.Helper.Translation.Get("config.manual-key.description")
            );

            // RAM Threshold Settings
            configMenu.AddBoolOption(
                this.ModManifest,
                () => this.Config.EnableRamThreshold,
                v => this.Config.EnableRamThreshold = v,
                () => this.Helper.Translation.Get("config.ram-enable.name"),
                () => this.Helper.Translation.Get("config.ram-enable.description")
            );

            configMenu.AddNumberOption(
                this.ModManifest,
                () => this.Config.RamThresholdMB,
                v => this.Config.RamThresholdMB = v,
                () => this.Helper.Translation.Get("config.ram-value.name"),
                () => this.Helper.Translation.Get("config.ram-value.description"),
                min: 512,
                max: 16384,
                interval: 128
            );
        }

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (this.CooldownTicks > 0)
            {
                this.CooldownTicks--;
                return;
            }

            if (!this.Config.EnableRamThreshold || !Context.IsWorldReady) return;

            if (++this.TicksSinceLastRamCheck >= 1800) // Check every 30 seconds
            {
                this.TicksSinceLastRamCheck = 0;
                this.CheckRamUsage();
            }
        }

        private void CheckRamUsage()
        {
            using Process proc = Process.GetCurrentProcess();
            long currentRam = proc.PrivateMemorySize64 / (1024 * 1024);

            if (currentRam > this.Config.RamThresholdMB)
            {
                this.Monitor.Log($"RAM Usage ({currentRam} MB) exceeded limit ({this.Config.RamThresholdMB} MB). Purging...", LogLevel.Warn);
                this.PerformCacheClear("Auto-RAM");
                this.CooldownTicks = 18000; // 5 minute cooldown
            }
        }

        private void OnButtonPressed(object? sender, ButtonPressedEventArgs e)
        {
            if (Context.IsWorldReady && e.Button == this.Config.ManualClearKey)
                this.PerformCacheClear("Manual");
        }

        private void OnDayEnding(object? sender, DayEndingEventArgs e)
        {
            if (this.Config.AutoClearAtSleep)
                this.PerformCacheClear("Scheduled");
        }

        private void PerformCacheClear(string type)
        {
            try
            {
                // SMART PURGE: Filter out UI assets
                this.Helper.GameContent.InvalidateCache(asset =>
                {
                    if (asset.DataType != typeof(Texture2D)) return false;

                    string name = asset.Name.Name;
                    if (name.StartsWith("LooseSprites/Cursors") ||
                        name.StartsWith("LooseSprites/font") ||
                        name.StartsWith("LooseSprites/ControllerMaps"))
                    {
                        return false;
                    }

                    return true;
                });

                // Force Garbage Collection
                GC.Collect();
                GC.WaitForPendingFinalizers();

                // Show message
                if (type == "Manual" || type == "Auto-RAM")
                    Game1.addHUDMessage(new HUDMessage(this.Helper.Translation.Get("hud.purged"), 2));
            }
            catch (Exception ex)
            {
                this.Monitor.Log($"Cache purge failed: {ex.Message}", LogLevel.Error);
            }
        }
    }
}