using System;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;

namespace MassAnimalMover
{
    public class ModEntry : Mod
    {
        // 1. Add the Config property
        private ModConfig Config;

        public override void Entry(IModHelper helper)
        {
            // 2. Read the config file (creates default if missing)
            this.Config = helper.ReadConfig<ModConfig>();

            helper.Events.Input.ButtonPressed += OnButtonPressed;
            
            // 3. Listen for GameLaunched to hook into GMCM
            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
        }

        private void OnGameLaunched(object sender, GameLaunchedEventArgs e)
        {
            // 4. Get the GMCM API
            var configMenu = this.Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
            
            if (configMenu != null)
            {
                // Register the mod
                configMenu.Register(
                    mod: this.ModManifest,
                    reset: () => this.Config = new ModConfig(),
                    save: () => this.Helper.WriteConfig(this.Config)
                );

                // Add the Keybind setting to the menu
                configMenu.AddKeybind(
                    mod: this.ModManifest,
                    getValue: () => this.Config.OpenMenuKey,
                    setValue: value => this.Config.OpenMenuKey = value,
                    name: () => "Open Menu Key",
                    tooltip: () => "The key to open the Mass Animal Mover menu."
                );
            }
        }

        private void OnButtonPressed(object sender, ButtonPressedEventArgs e)
        {
            if (!Context.IsWorldReady || !Context.IsPlayerFree)
                return;

            // 5. Use the Config key instead of hardcoded 'M'
            if (this.Config.OpenMenuKey.JustPressed())
            {
                Game1.activeClickableMenu = new UI.TransferMenu();
            }
        }
    }
}