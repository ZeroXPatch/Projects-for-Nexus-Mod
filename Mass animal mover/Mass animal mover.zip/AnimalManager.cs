using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewModdingAPI; // Added for logging
using StardewValley;
using StardewValley.Buildings;

namespace MassAnimalMover
{
    public static class AnimalManager
    {
        public static string TransferAnimals(Building sourceParams, Building destParams, List<long> animalIdsToMove)
        {
            if (sourceParams == null || destParams == null) return "Building not found.";
            if (sourceParams == destParams) return "Cannot move to same building.";

            AnimalHouse destIndoors = destParams.GetIndoors() as AnimalHouse;
            AnimalHouse sourceIndoors = sourceParams.GetIndoors() as AnimalHouse;

            if (destIndoors == null) return "Destination is not an animal building.";

            // 1. Capacity Check
            int capacity = destParams.maxOccupants.Value;
            int destCurrentCount = GetAnimalCount(destParams);

            if (destCurrentCount + animalIdsToMove.Count > capacity)
                return $"Not enough space! Slots left: {capacity - destCurrentCount}";

            int movedCount = 0;
            var farm = Game1.getFarm();

            foreach (long animalId in animalIdsToMove)
            {
                FarmAnimal animal = null;

                // --- FIND ANIMAL ---
                if (sourceIndoors != null && sourceIndoors.animals.TryGetValue(animalId, out FarmAnimal insideAnimal))
                    animal = insideAnimal;
                else if (farm.animals.TryGetValue(animalId, out FarmAnimal outsideAnimal))
                    animal = outsideAnimal;

                if (animal == null)
                {
                    Console.WriteLine($"[MassAnimalMover] Could not find animal with ID {animalId}");
                    continue;
                }

                // --- EXECUTE MOVE (Validation Removed for Flexibility) ---

                // 1. Remove from old location
                if (sourceIndoors != null && sourceIndoors.animals.ContainsKey(animalId))
                    sourceIndoors.animals.Remove(animalId);

                if (farm.animals.ContainsKey(animalId))
                    farm.animals.Remove(animalId);

                // 2. Add to new location
                // We always add to the indoors list first. The game handles moving them out later.
                destIndoors.animals.Add(animalId, animal);

                // 3. Update Home Data
                animal.home = destParams;
                // Note: We do NOT touch homeLocation.Value anymore, setting .home is sufficient in 1.6

                // 4. Teleport Visuals
                if (animal.currentLocation == sourceIndoors)
                {
                    // If they were inside, move them to the new inside
                    animal.currentLocation = destIndoors;
                    animal.Position = new Vector2(100, 100);
                }
                else
                {
                    // If they were outside, keep them outside but move to new door
                    // IMPORTANT: If they are outside, they MUST be in farm.animals to be visible
                    if (animal.currentLocation == farm)
                    {
                        destIndoors.animals.Remove(animalId); // Don't double count
                        farm.animals.Add(animalId, animal);   // Add back to farm logic
                    }

                    Vector2 doorLocation = new Vector2(
                        destParams.tileX.Value + destParams.humanDoor.X,
                        destParams.tileY.Value + destParams.humanDoor.Y + 1
                    );
                    animal.Position = doorLocation * 64f;
                }

                movedCount++;
            }

            return $"Moved {movedCount} animals.";
        }

        private static int GetAnimalCount(Building b)
        {
            int count = 0;
            // Count animals inside
            if (b.GetIndoors() is AnimalHouse indoors)
                count += indoors.animals.Count();

            // Count animals outside that belong to this building
            foreach (var a in Game1.getFarm().animals.Values)
            {
                if (a.home == b) count++;
            }
            return count;
        }
    }
}