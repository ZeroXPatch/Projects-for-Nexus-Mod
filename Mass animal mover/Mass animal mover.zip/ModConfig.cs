using StardewModdingAPI.Utilities;

namespace MassAnimalMover
{
    public class ModConfig
    {
        // Changed default from "M" to "Z"
        public KeybindList OpenMenuKey { get; set; } = KeybindList.Parse("Z");
    }
}