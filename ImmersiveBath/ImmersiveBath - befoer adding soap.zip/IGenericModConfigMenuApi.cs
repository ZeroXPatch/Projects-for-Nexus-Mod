using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using StardewModdingAPI;
using StardewModdingAPI.Utilities;

namespace ImmersiveBath
{
    /// <summary>The API provided by the Generic Mod Config Menu mod.</summary>
    public interface IGenericModConfigMenuApi
    {
        /*********
        ** Methods
        *********/
        /****
        ** Must be called first
        ****/
        /// <summary>Register a mod whose config can be edited through the UI.</summary>
        /// <param name="mod">The mod's manifest.</param>
        /// <param name="reset">Reset the config to its default values.</param>
        /// <param name="save">Save the current config to the config file.</param>
        /// <param name="titleScreenOnly">Whether the options can only be edited from the title screen.</param>
        void Register(IManifest mod, Action reset, Action save, bool titleScreenOnly = false);


        /****
        ** Basic options
        ****/
        /// <summary>Add a section title at the current position in the form.</summary>
        /// <param name="mod">The mod's manifest.</param>
        /// <param name="text">The title text to display.</param>
        /// <param name="tooltip">The tooltip text shown when the cursor hovers over the title, if any.</param>
        void AddSectionTitle(IManifest mod, Func<string> text, Func<string> tooltip = null);

        /// <summary>Add a boolean option at the current position in the form.</summary>
        /// <param name="mod">The mod's manifest.</param>
        /// <param name="getValue">Get the current value from the mod config.</param>
        /// <param name="setValue">Set a new value in the mod config.</param>
        /// <param name="name">The label text to display in the form.</param>
        /// <param name="tooltip">The tooltip text shown when the cursor hovers over the field, if any.</param>
        /// <param name="fieldId">The unique ID for this field, or null to generate one.</param>
        void AddBoolOption(IManifest mod, Func<bool> getValue, Action<bool> setValue, Func<string> name, Func<string> tooltip = null, string fieldId = null);

        /// <summary>Add an integer option at the current position in the form.</summary>
        /// <param name="mod">The mod's manifest.</param>
        /// <param name="getValue">Get the current value from the mod config.</param>
        /// <param name="setValue">Set a new value in the mod config.</param>
        /// <param name="name">The label text to display in the form.</param>
        /// <param name="tooltip">The tooltip text shown when the cursor hovers over the field, if any.</param>
        /// <param name="min">The minimum allowed value, if any.</param>
        /// <param name="max">The maximum allowed value, if any.</param>
        /// <param name="interval">The interval of values when ticking (e.g. 10 to interate by 10's), if any.</param>
        /// <param name="formatValue">Get the display text to show for a value, or null to show the number as-is.</param>
        /// <param name="fieldId">The unique ID for this field, or null to generate one.</param>
        void AddNumberOption(IManifest mod, Func<int> getValue, Action<int> setValue, Func<string> name, Func<string> tooltip = null, int? min = null, int? max = null, int? interval = null, Func<int, string> formatValue = null, string fieldId = null);

        /// <summary>Add a float option at the current position in the form.</summary>
        /// <param name="mod">The mod's manifest.</param>
        /// <param name="getValue">Get the current value from the mod config.</param>
        /// <param name="setValue">Set a new value in the mod config.</param>
        /// <param name="name">The label text to display in the form.</param>
        /// <param name="tooltip">The tooltip text shown when the cursor hovers over the field, if any.</param>
        /// <param name="min">The minimum allowed value, if any.</param>
        /// <param name="max">The maximum allowed value, if any.</param>
        /// <param name="interval">The interval of values when ticking, if any.</param>
        /// <param name="formatValue">Get the display text to show for a value, or null to show the number as-is.</param>
        /// <param name="fieldId">The unique ID for this field, or null to generate one.</param>
        void AddNumberOption(IManifest mod, Func<float> getValue, Action<float> setValue, Func<string> name, Func<string> tooltip = null, float? min = null, float? max = null, float? interval = null, Func<float, string> formatValue = null, string fieldId = null);

        /// <summary>Add a string option at the current position in the form.</summary>
        /// <param name="mod">The mod's manifest.</param>
        /// <param name="getValue">Get the current value from the mod config.</param>
        /// <param name="setValue">Set a new value in the mod config.</param>
        /// <param name="name">The label text to display in the form.</param>
        /// <param name="tooltip">The tooltip text shown when the cursor hovers over the field, if any.</param>
        /// <param name="allowedValues">The values that can be selected, or null for any value.</param>
        /// <param name="formatAllowedValue">Get the display text to show for a value from <paramref name="allowedValues"/>, or null to show the values as-is.</param>
        /// <param name="fieldId">The unique ID for this field, or null to generate one.</param>
        void AddTextOption(IManifest mod, Func<string> getValue, Action<string> setValue, Func<string> name, Func<string> tooltip = null, string[] allowedValues = null, Func<string, string> formatAllowedValue = null, string fieldId = null);
    }
}