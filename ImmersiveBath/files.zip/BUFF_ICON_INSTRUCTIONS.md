# How to Prepare Buff Icons

## IMPORTANT: Buff Icon Size
Stardew Valley buff icons MUST be **16x16 pixels**. The emotes from the wiki are 56x56 pixels and need to be resized.

## Required Files

You need TWO buff icon files for this mod:

### 1. heart_buff.png (Clean Buff - 80-100% cleanliness)
- **File name**: `heart_buff.png`
- **Size**: 16x16 pixels
- **Icon**: Heart emote (shows friendship bonus)
- **Status**: ✓ Provided by user

### 2. sick_emote.png (Unclean Debuff - Below 40% cleanliness)
- **File name**: `sick_emote.png`
- **Size**: 16x16 pixels  
- **Icon**: Sick emote (green sick face)
- **Status**: Needs to be created from wiki emote

---

## How to Create sick_emote.png

### Download the Emote
1. Go to: https://stardewvalleywiki.com/File:Emote_Sick.gif
2. Right-click the emote image in the thumbnail section
3. Save the image (it will be 56x56 pixels)

### Resize to 16x16 pixels

**Option 1: Using an Image Editor (GIMP, Photoshop, Paint.NET)**
1. Open Emote_Sick.gif
2. Image → Scale/Resize
3. Set dimensions to: 16 x 16 pixels
4. Use "Nearest Neighbor" or "None" interpolation to keep pixel art sharp
5. Export as PNG: `sick_emote.png`

**Option 2: Using Online Tool**
1. Go to https://www.birme.net/ or similar image resizer
2. Upload Emote_Sick.gif
3. Set size to 16x16 pixels
4. Download as PNG
5. Rename to: `sick_emote.png`

**Option 3: Using ImageMagick (Command Line)**
```bash
magick Emote_Sick.gif -resize 16x16 sick_emote.png
```

### Important Resize Settings
- **Target size**: 16x16 pixels (this is critical!)
- **Interpolation**: Use "Nearest Neighbor" to preserve pixel art look
- **Format**: PNG with transparency
- **Don't**: Use blur or smooth interpolation - it will make the icon fuzzy

---

## Where to Place the Files

Put both PNG files in your mod's assets folder:

```
ImmersiveBath/
  ├── assets/
  │   ├── sponge.png
  │   ├── soap.png
  │   ├── heart_buff.png      ← Place here (16x16 PNG)
  │   └── sick_emote.png      ← Place here (16x16 PNG)
  ├── ModEntry.cs
  ├── ModConfig.cs
  └── ...
```

---

## File Specifications

Both files must meet these requirements:
- **Format**: PNG (not GIF, not JPG)
- **Size**: Exactly 16x16 pixels
- **Transparency**: Preserve transparent background
- **Color mode**: RGB or RGBA

---

## Testing

After adding both files:
1. Compile your mod
2. Run Stardew Valley
3. **Test Clean Buff (80-100%)**:
   - Stay clean
   - Check buffs - you should see heart icon with "Clean" buff
   - Talk to NPCs - should gain friendship
4. **Test Unclean Debuff (below 40%)**:
   - Let cleanliness drop below 40%
   - Check buffs - you should see sick emote icon with "Unclean" debuff
   - Talk to NPCs - should lose friendship and NPC shows angry emote

---

## Troubleshooting

**Icons too large/covering UI:**
- Check file size - must be exactly 16x16 pixels
- Use image properties to verify dimensions

**Icons not showing:**
- Verify files are named correctly: `heart_buff.png` and `sick_emote.png`
- Check they're in the `assets/` folder
- Make sure they're PNG format, not GIF
- Recompile the mod after adding files

**Icons look blurry:**
- Use "Nearest Neighbor" interpolation when resizing
- Don't use smooth/bilinear/bicubic interpolation
