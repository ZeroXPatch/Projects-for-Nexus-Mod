﻿namespace WoodPileStorage
{
    public class ModConfig
    {
        public bool EnableAutoDeposit { get; set; } = true;
        public int AutoDepositRange { get; set; } = 1;

        // New: How many seconds to wait after closing menu before auto-suck starts
        public int AutoDepositCooldown { get; set; } = 15;
    }
}