using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Menus;
using StardewValley.Objects;

namespace WoodPileStorage
{
    public class ModEntry : Mod
    {
        private Chest? virtualChest;
        private const string SaveKey = "wood-pile-inventory";

        // Configuration
        private ModConfig config = new();

        // Logic state
        private bool wasMenuOpen = false;
        private double cooldownTime = 0;

        public override void Entry(IModHelper helper)
        {
            // Load Config
            this.config = helper.ReadConfig<ModConfig>();

            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
            helper.Events.Input.ButtonPressed += OnButtonPressed;
            helper.Events.GameLoop.SaveLoaded += OnSaveLoaded;
            helper.Events.GameLoop.Saving += OnSaving;
            helper.Events.GameLoop.UpdateTicked += OnUpdateTicked;
        }

        private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
        {
            // Connect to Generic Mod Config Menu
            var configMenu = this.Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
            if (configMenu == null) return;

            configMenu.Register(
                mod: this.ModManifest,
                reset: () => this.config = new ModConfig(),
                save: () => this.Helper.WriteConfig(this.config)
            );

            // 1. Enable/Disable Auto-Deposit
            configMenu.AddBoolOption(
                mod: this.ModManifest,
                name: () => "Enable Auto-Deposit",
                tooltip: () => "If true, wood is automatically sucked from your inventory when you get close.",
                getValue: () => this.config.EnableAutoDeposit,
                setValue: value => this.config.EnableAutoDeposit = value
            );

            // 2. Range Slider
            configMenu.AddNumberOption(
                mod: this.ModManifest,
                name: () => "Auto-Deposit Range",
                tooltip: () => "How many tiles away you can be for auto-deposit to work.",
                getValue: () => this.config.AutoDepositRange,
                setValue: value => this.config.AutoDepositRange = value,
                min: 1,
                max: 10
            );

            // 3. Cooldown Slider (NEW)
            configMenu.AddNumberOption(
                mod: this.ModManifest,
                name: () => "Cooldown (Seconds)",
                tooltip: () => "How many seconds to wait after closing the menu before Auto-Deposit turns back on. Prevents the pile from instantly sucking back what you just took out.",
                getValue: () => this.config.AutoDepositCooldown,
                setValue: value => this.config.AutoDepositCooldown = value,
                min: 0,
                max: 60
            );
        }

        private void OnSaveLoaded(object? sender, SaveLoadedEventArgs e)
        {
            virtualChest = new Chest(playerChest: true);
            var savedItems = this.Helper.Data.ReadSaveData<List<Item>>(SaveKey);

            if (savedItems != null)
            {
                foreach (var item in savedItems)
                {
                    virtualChest.Items.Add(item);
                }
            }
        }

        private void OnSaving(object? sender, SavingEventArgs e)
        {
            if (virtualChest == null) return;

            for (int i = virtualChest.Items.Count - 1; i >= 0; i--)
            {
                if (virtualChest.Items[i] == null)
                    virtualChest.Items.RemoveAt(i);
            }
            this.Helper.Data.WriteSaveData(SaveKey, virtualChest.Items);
        }

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady || !Context.IsPlayerFree) return;
            if (Game1.currentLocation is not Farm) return;

            // --- Menu Logic ---
            bool isMenuOpen = Game1.activeClickableMenu is ItemGrabMenu menu && menu.sourceItem == virtualChest;

            if (wasMenuOpen && !isMenuOpen)
            {
                // Menu just closed: Set cooldown based on Config
                cooldownTime = Game1.currentGameTime.TotalGameTime.TotalSeconds + config.AutoDepositCooldown;
            }
            wasMenuOpen = isMenuOpen;

            // --- Auto Deposit Logic ---

            // 1. If Auto-Deposit is disabled in config, STOP.
            if (!config.EnableAutoDeposit) return;

            // 2. If Menu is open OR we are in cooldown, STOP.
            if (isMenuOpen || Game1.currentGameTime.TotalGameTime.TotalSeconds < cooldownTime) return;

            // 3. Check Distance
            if (IsNearWoodPile(Game1.player.Tile))
            {
                // Hover effect (Visual only)
                if (IsWoodPile(this.Helper.Input.GetCursorPosition().Tile))
                {
                    Game1.mouseCursor = Game1.cursor_grab;
                }

                // Run logic every 15 ticks
                if (e.IsMultipleOf(15))
                {
                    AutoStoreWood();
                }
            }
        }

        private void AutoStoreWood()
        {
            if (virtualChest == null) return;

            bool movedAnything = false;
            int totalWoodMoved = 0;

            for (int i = Game1.player.Items.Count - 1; i >= 0; i--)
            {
                Item item = Game1.player.Items[i];
                if (item == null) continue;

                if (item.ItemId == "388" || item.ItemId == "709")
                {
                    Item leftover = virtualChest.addItem(item);

                    int amountMoved = item.Stack;
                    if (leftover != null) amountMoved -= leftover.Stack;

                    if (amountMoved > 0)
                    {
                        movedAnything = true;
                        totalWoodMoved += amountMoved;

                        if (leftover == null)
                            Game1.player.Items[i] = null;
                        else
                            Game1.player.Items[i] = leftover;
                    }
                }
            }

            if (movedAnything)
            {
                Game1.playSound("coin");
                Game1.addHUDMessage(new HUDMessage($"+{totalWoodMoved} Wood Stored", 1));
            }
        }

        private void OnButtonPressed(object? sender, ButtonPressedEventArgs e)
        {
            if (!Context.IsWorldReady || !Context.IsPlayerFree) return;
            if (!e.Button.IsActionButton()) return;
            if (Game1.currentLocation is not Farm) return;

            Vector2 clickedTile = e.Cursor.GrabTile;

            // Manual interaction logic
            if (IsWoodPile(clickedTile))
            {
                if (Utility.distance(Game1.player.Tile.X, clickedTile.X, Game1.player.Tile.Y, clickedTile.Y) <= 2f)
                {
                    this.Helper.Input.Suppress(e.Button);
                    OpenWoodPileMenu();
                }
            }
        }

        private bool IsNearWoodPile(Vector2 playerTile)
        {
            Point entry = Game1.getFarm().GetMainFarmHouseEntry();
            float range = (float)config.AutoDepositRange;
            return Utility.distance(playerTile.X, entry.X - 4, playerTile.Y, entry.Y) <= range;
        }

        private bool IsWoodPile(Vector2 tile)
        {
            Point farmhouseEntry = Game1.getFarm().GetMainFarmHouseEntry();
            bool validX = tile.X >= farmhouseEntry.X - 7 && tile.X <= farmhouseEntry.X - 1;
            bool validY = tile.Y >= farmhouseEntry.Y - 1 && tile.Y <= farmhouseEntry.Y;
            return validX && validY;
        }

        private void OpenWoodPileMenu()
        {
            if (virtualChest == null) virtualChest = new Chest(playerChest: true);
            Game1.playSound("woodWhack");

            // FIX: We wire the "OnItemSelect" directly to the virtual chest's "grabItemFromInventory".
            // This allows the game to handle the math of moving stacks, ensuring NO DUPLICATION bugs.

            var menu = new ItemGrabMenu(
                virtualChest.Items,     // Inventory
                false,                  // reverseGrab
                true,                   // showReceivingMenu
                InventoryHighlight,     // highlightFunction
                virtualChest.grabItemFromInventory, // behaviorOnItemSelect (Linked to Chest Logic)
                null,                   // message
                null,                   // behaviorOnItemGrab
                false,                  // snapToBottom
                true,                   // canBeExitedWithKey
                true,                   // playRightClickSound
                true,                   // allowRightClick
                true,                   // showOrganizeButton
                1,                      // source
                virtualChest,           // sourceItem
                -1,                     // whichSpecialButton
                this                    // context
            );

            Game1.activeClickableMenu = menu;
            wasMenuOpen = true;
        }

        private bool InventoryHighlight(Item item)
        {
            // 1. Allow items in the top chest
            if (virtualChest != null && virtualChest.Items.Contains(item))
            {
                return true;
            }

            // 2. Allow Player Wood/Hardwood
            if (item != null && (item.ItemId == "388" || item.ItemId == "709"))
            {
                return true;
            }

            // 3. Block everything else
            return false;
        }
    }
}