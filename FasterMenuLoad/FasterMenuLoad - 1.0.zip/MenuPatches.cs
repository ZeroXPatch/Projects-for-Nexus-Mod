using HarmonyLib;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Menus;
using System;
using System.Collections.Generic;

namespace FasterMenuLoad
{
    public static class MenuPatches
    {
        public static void Apply(Harmony harmony)
        {
            harmony.Patch(
                original: AccessTools.Constructor(typeof(GameMenu), new[] { typeof(bool) }),
                postfix: new HarmonyMethod(typeof(MenuPatches), nameof(GameMenu_Ctor_Postfix))
            );

            harmony.Patch(
                original: AccessTools.Method(typeof(GameMenu), nameof(GameMenu.changeTab)),
                prefix: new HarmonyMethod(typeof(MenuPatches), nameof(ChangeTab_Prefix))
            );
        }

        private static void GameMenu_Ctor_Postfix(GameMenu __instance)
        {
            List<IClickableMenu> pages = __instance.pages;
            var monitor = ModEntry.ModMonitor;

            // --- HELPER FUNCTION ---
            // Replaces a page with a LazyTab that knows how to recreate the original page.
            void ReplaceWithLazy(int index, string name)
            {
                if (index < 0 || index >= pages.Count) return;

                var originalPage = pages[index];
                if (originalPage == null) return;

                // Capture the exact type of the page (e.g., SocialPage, SkillsPage, or a Modded subclass)
                Type originalType = originalPage.GetType();

                // Define how to recreate this page later
                IClickableMenu Generator(int x, int y, int w, int h)
                {
                    try
                    {
                        // 1. Special Handling for Crafting (it has an extra 'cooking' boolean)
                        if (originalType == typeof(CraftingPage))
                        {
                            // We can detect if it's cooking by checking the original property, 
                            // but since we are replacing it fresh, we rely on standard Tab 4 behavior.
                            // Tab 4 is Crafting (false), Cooking is usually a separate state but in GameMenu it's just CraftingPage.
                            // However, if the user has a mod that adds a separate Cooking tab, we need to be careful.
                            // Standard GameMenu: Tab 4 is Crafting.
                            bool isCooking = false;
                            // If we really need to know, we'd have to cast originalPage to CraftingPage and check .cooking
                            // But originalPage is gone by the time this runs? No, we can check now.
                            if (originalPage is CraftingPage cp) isCooking = cp.cooking;

                            return new CraftingPage(x, y, w, h, isCooking);
                        }

                        // 2. Generic Handling for everything else (Skills, Social, Animals, Powers, Collections)
                        // Most pages have a constructor: Name(int x, int y, int width, int height)
                        return (IClickableMenu)Activator.CreateInstance(originalType, x, y, w, h);
                    }
                    catch (Exception ex)
                    {
                        monitor.Log($"[ERROR] LazyTab failed to recreate {name} ({originalType.Name}). Error: {ex.Message}", LogLevel.Error);
                        return new InventoryPage(x, y, w, h); // Fallback to avoid crash
                    }
                }

                // Perform the swap
                pages[index] = new LazyTab(originalPage.xPositionOnScreen, originalPage.yPositionOnScreen, originalPage.width, originalPage.height, Generator);
                monitor.Log($"[SUCCESS] Swapped {name} (Tab {index} - {originalType.Name}) with LazyTab.", LogLevel.Trace);
            }

            // --- APPLY SWAPS ---
            // Note: Indices based on Stardew Valley 1.6 Standard Menu

            // Tab 1: Skills
            if (ModEntry.Config.LazyLoadSkills)
                ReplaceWithLazy(1, "Skills");

            // Tab 2: Social
            if (ModEntry.Config.LazyLoadSocial)
                ReplaceWithLazy(2, "Social");

            // Tab 4: Crafting
            if (ModEntry.Config.LazyLoadCrafting)
                ReplaceWithLazy(4, "Crafting");

            // Tab 5: Animals (New in 1.6)
            if (ModEntry.Config.LazyLoadAnimals)
                ReplaceWithLazy(5, "Animals");

            // Tab 6: Special Items & Powers (New in 1.6)
            if (ModEntry.Config.LazyLoadPowers)
                ReplaceWithLazy(6, "Powers");

            // Tab 7: Collections
            if (ModEntry.Config.LazyLoadCollections)
                ReplaceWithLazy(7, "Collections");


            // --- FAILSAFE ---
            // If the game forced us to open on a specific tab (like pressing 'Y' for Collections),
            // we must wake that specific tab up immediately.
            if (__instance.currentTab >= 0 && __instance.currentTab < pages.Count)
            {
                if (pages[__instance.currentTab] is LazyTab lazy)
                {
                    monitor.Log($"[FAILSAFE] Menu opened directly on Tab {__instance.currentTab}. Waking it up immediately.", LogLevel.Info);
                    pages[__instance.currentTab] = lazy.CreateRealPage();
                }
            }
        }

        private static void ChangeTab_Prefix(GameMenu __instance, int whichTab)
        {
            if (whichTab < 0 || whichTab >= __instance.pages.Count) return;

            if (__instance.pages[whichTab] is LazyTab lazyTab)
            {
                // Hydrate the tab right before the game switches to it
                __instance.pages[whichTab] = lazyTab.CreateRealPage();

                // Controller support: snap cursor to the new real page
                if (Game1.options.gamepadControls)
                {
                    __instance.pages[whichTab].snapToDefaultClickableComponent();
                }
            }
        }
    }
}