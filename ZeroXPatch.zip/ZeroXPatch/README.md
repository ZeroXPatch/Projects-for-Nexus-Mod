# ZeroXPatch - Debris Performance Optimizer

## Description
ZeroXPatch is a Stardew Valley SMAPI mod that improves game performance when there's a lot of debris on screen. This is especially helpful when using mods that increase drop rates (like custom drop rate mods), which can cause stuttering when cutting trees or mining rocks.

## Features
- **Automatic Debris Limiting**: Caps the maximum number of debris items on screen
- **Physics Optimization**: Disables physics for debris that's far from the player
- **Configurable Settings**: Customize thresholds and behavior to your preference
- **No Drop Rate Changes**: Maintains your desired drop rates while improving performance

## Installation
1. Install [SMAPI](https://smapi.io/)
2. Download this mod
3. Extract the `ZeroXPatch` folder into your `Stardew Valley/Mods` folder
4. Run the game using SMAPI

## Configuration
After running the game once, a `config.json` file will be created in the mod folder. You can edit it to customize the mod's behavior:

```json
{
  "MaxDebrisCount": 150,
  "EnableDebrisLimit": true,
  "PhysicsDisableDistance": 800.0,
  "DisableDistantDebrisPhysics": true,
  "UpdateFrequency": 30,
  "ShowDebugInfo": false,
  "WarningThreshold": 100
}
```

### Configuration Options

- **MaxDebrisCount** (default: 150): Maximum number of debris items allowed before cleanup starts. Lower values = better performance but less visual clutter.

- **EnableDebrisLimit** (default: true): Enable/disable automatic debris removal when limit is reached.

- **PhysicsDisableDistance** (default: 800): Distance in pixels beyond which debris physics are frozen. Larger values = more realistic but lower performance.

- **DisableDistantDebrisPhysics** (default: true): Enable/disable physics optimization for distant debris.

- **UpdateFrequency** (default: 30): How often to check debris count, in ticks (60 ticks = 1 second). Higher values = lower overhead but less responsive.

- **ShowDebugInfo** (default: false): Show debug logging for debris counts.

- **WarningThreshold** (default: 100): Debris count at which warnings are logged.

## How It Works
1. The mod monitors the number of debris items (wood, stone, etc.) on the current map
2. When debris count exceeds the configured limit, it removes the oldest debris first (FIFO)
3. Debris far from the player has its physics disabled to reduce CPU usage
4. This allows you to keep high drop rates without performance issues

## Compatibility
- Requires SMAPI 4.0.0 or later
- Compatible with Stardew Valley 1.6+
- Works with any drop rate modification mods
- Should be compatible with most other mods

## Recommended Settings
For heavy drop rate mods (3x-5x normal):
- MaxDebrisCount: 100-150
- PhysicsDisableDistance: 600

For extreme drop rate mods (10x+ normal):
- MaxDebrisCount: 75-100
- PhysicsDisableDistance: 400

## Building from Source
1. Install .NET 6.0 SDK
2. Navigate to the mod directory
3. Run `dotnet build`
4. The compiled mod will be in `bin/Debug/net6.0/`

## Troubleshooting
**Still experiencing stuttering?**
- Lower the MaxDebrisCount value
- Reduce PhysicsDisableDistance
- Decrease UpdateFrequency for more responsive cleanup

**Items disappearing too quickly?**
- Increase MaxDebrisCount
- Disable debris limiting: set EnableDebrisLimit to false

## License
This mod is provided as-is for personal use.

## Credits
Created in response to performance issues when using high drop rate mods with resource gathering.
