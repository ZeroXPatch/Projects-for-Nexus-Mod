using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.TerrainFeatures;

namespace ZeroXPatch
{
    public class ModEntry : Mod
    {
        private ModConfig Config;
        private int debrisCount = 0;
        private int updateCounter = 0;

        public override void Entry(IModHelper helper)
        {
            this.Config = this.Helper.ReadConfig<ModConfig>();

            helper.Events.GameLoop.UpdateTicked += this.OnUpdateTicked;
            helper.Events.Display.RenderedWorld += this.OnRenderedWorld;
            
            this.Monitor.Log("ZeroXPatch loaded! Debris performance optimization active.", LogLevel.Info);
        }

        private void OnUpdateTicked(object sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady)
                return;

            // Only check every few ticks to reduce overhead
            updateCounter++;
            if (updateCounter < this.Config.UpdateFrequency)
                return;
            
            updateCounter = 0;

            var location = Game1.currentLocation;
            if (location == null)
                return;

            // Count debris
            debrisCount = location.debris.Count;

            // If debris count is high, optimize by removing excess
            if (debrisCount > this.Config.MaxDebrisCount && this.Config.EnableDebrisLimit)
            {
                int toRemove = debrisCount - this.Config.MaxDebrisCount;
                
                // Remove oldest debris first (FIFO)
                for (int i = 0; i < toRemove && location.debris.Count > 0; i++)
                {
                    location.debris.RemoveAt(0);
                }
                
                this.Monitor.Log($"Removed {toRemove} debris items to maintain performance. Current count: {location.debris.Count}", LogLevel.Trace);
            }

            // Disable physics for distant debris
            if (this.Config.DisableDistantDebrisPhysics)
            {
                Vector2 playerPos = Game1.player.Position;
                
                foreach (var debris in location.debris)
                {
                    float distance = Vector2.Distance(playerPos, debris.Chunks[0].position.Value);
                    
                    // Freeze debris that's far from player
                    if (distance > this.Config.PhysicsDisableDistance)
                    {
                        foreach (var chunk in debris.Chunks)
                        {
                            chunk.xVelocity.Value = 0f;
                            chunk.yVelocity.Value = 0f;
                            chunk.rotationVelocity = 0f;
                        }
                    }
                }
            }
        }

        private void OnRenderedWorld(object sender, RenderedWorldEventArgs e)
        {
            if (!Context.IsWorldReady || !this.Config.ShowDebugInfo)
                return;

            // Draw debug info
            string debugText = $"Debris Count: {debrisCount}";
            if (debrisCount > this.Config.MaxDebrisCount && this.Config.EnableDebrisLimit)
            {
                debugText += " [LIMITING]";
            }

            // This would require SpriteBatch drawing which is more complex
            // For now, we'll just log it
            if (debrisCount > this.Config.WarningThreshold)
            {
                this.Monitor.Log($"High debris count detected: {debrisCount}", LogLevel.Trace);
            }
        }
    }

    public class ModConfig
    {
        /// <summary>Maximum number of debris items allowed on screen before cleanup starts.</summary>
        public int MaxDebrisCount { get; set; } = 150;

        /// <summary>Enable automatic debris limiting.</summary>
        public bool EnableDebrisLimit { get; set; } = true;

        /// <summary>Disable physics for debris beyond this distance (in pixels).</summary>
        public float PhysicsDisableDistance { get; set; } = 800f;

        /// <summary>Disable physics calculations for distant debris.</summary>
        public bool DisableDistantDebrisPhysics { get; set; } = true;

        /// <summary>How often to check debris count (in ticks, 60 = 1 second).</summary>
        public int UpdateFrequency { get; set; } = 30;

        /// <summary>Show debug information about debris count.</summary>
        public bool ShowDebugInfo { get; set; } = false;

        /// <summary>Debris count threshold for warnings.</summary>
        public int WarningThreshold { get; set; } = 100;
    }
}
