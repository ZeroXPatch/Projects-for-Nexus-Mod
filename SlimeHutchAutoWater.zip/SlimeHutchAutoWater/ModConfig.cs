﻿namespace SlimeHutchAutoWater
{
    public class ModConfig
    {
        public bool Enabled { get; set; } = true;
    }
}