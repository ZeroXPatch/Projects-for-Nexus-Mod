using System;
using GenericModConfigMenu;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;
using StardewValley.Buffs;

namespace HorseMaster
{
    public class ModEntry : Mod
    {
        private ModConfig Config = new();
        private const string BuffId = "HorseMaster.SpeedBuff";

        // Cache the target speed to apply so we don't recalculate math every frame
        private int _cachedTargetSpeed = 0;

        public override void Entry(IModHelper helper)
        {
            this.Config = helper.ReadConfig<ModConfig>();

            helper.Events.GameLoop.GameLaunched += OnGameLaunched;
            helper.Events.GameLoop.UpdateTicked += OnUpdateTicked;
            helper.Events.Display.RenderedWorld += OnRenderedWorld;
        }

        private void OnUpdateTicked(object? sender, UpdateTickedEventArgs e)
        {
            if (!Context.IsWorldReady || Game1.player == null)
                return;

            // --- 1. INSTANT CHECK (Every Tick) ---
            // If we are NOT riding, kill the buff immediately.
            // This prevents "sliding" or fast walking after dismount.
            if (!Game1.player.isRidingHorse())
            {
                if (Game1.player.buffs.IsApplied(BuffId))
                {
                    Game1.player.buffs.Remove(BuffId);
                }
                return;
            }

            // --- 2. CALCULATION CHECK (Every 15 Ticks / 0.25s) ---
            // Update the math less frequently to save CPU.
            if (e.IsMultipleOf(15))
            {
                CalculateTargetSpeed();
            }

            // --- 3. APPLY BUFF ---
            ApplyHorseBuff();
        }

        private void CalculateTargetSpeed()
        {
            if (!this.Config.UseAdaptiveSpeed)
            {
                _cachedTargetSpeed = this.Config.ConstantSpeed;
                return;
            }

            // Calculate Energy %
            float current = Game1.player.Stamina;
            float max = Game1.player.MaxStamina > 0 ? Game1.player.MaxStamina : 1;
            float percent = (current / max) * 100f;

            // Determine Bracket
            if (percent > 99.5f) _cachedTargetSpeed = this.Config.Speed_100;
            else if (percent >= 70f) _cachedTargetSpeed = this.Config.Speed_99_to_70;
            else if (percent >= 40f) _cachedTargetSpeed = this.Config.Speed_69_to_40;
            else if (percent >= 10f) _cachedTargetSpeed = this.Config.Speed_39_to_10;
            else _cachedTargetSpeed = this.Config.Speed_09_to_00;
        }

        private void ApplyHorseBuff()
        {
            // If the target speed is 0, we don't need a buff.
            if (_cachedTargetSpeed == 0)
            {
                if (Game1.player.buffs.IsApplied(BuffId))
                    Game1.player.buffs.Remove(BuffId);
                return;
            }

            // Check if we need to update the existing buff
            if (Game1.player.buffs.IsApplied(BuffId))
            {
                var existing = Game1.player.buffs.AppliedBuffs[BuffId];
                // Optimization: Don't replace if the value is the same
                if (existing.effects.Speed.Value == _cachedTargetSpeed)
                    return;
            }

            // Create/Overwrite Buff
            Buff horseBuff = new Buff(
                id: BuffId,
                displayName: "Horse Master",
                iconTexture: null,
                iconSheetIndex: 0,
                duration: Buff.ENDLESS,
                effects: new BuffEffects()
                {
                    Speed = { _cachedTargetSpeed }
                }
            );

            Game1.player.applyBuff(horseBuff);
        }

        private void OnRenderedWorld(object? sender, RenderedWorldEventArgs e)
        {
            if (this.Config.DebugMode && Context.IsWorldReady && Game1.player != null && !Game1.eventUp && Game1.player.isRidingHorse())
            {
                Vector2 screenPos = Game1.GlobalToLocal(Game1.viewport, Game1.player.Position);
                Vector2 textPos = new Vector2(screenPos.X, screenPos.Y - 120);

                // Math for display
                float p = (Game1.player.Stamina / (float)Math.Max(1, Game1.player.MaxStamina)) * 100f;

                string debugText = $"Horse Master\nEnergy: {p:0.0}%\nAdded Speed: {_cachedTargetSpeed}";

                e.SpriteBatch.DrawString(Game1.dialogueFont, debugText, textPos, Color.Orange);
            }
        }

        // --- GMCM Registration ---
        private void OnGameLaunched(object? sender, GameLaunchedEventArgs e)
        {
            var configMenu = this.Helper.ModRegistry.GetApi<IGenericModConfigMenuApi>("spacechase0.GenericModConfigMenu");
            if (configMenu is null) return;

            configMenu.Register(this.ModManifest, () => this.Config = new ModConfig(), () => this.Helper.WriteConfig(this.Config));

            // General
            configMenu.AddSectionTitle(this.ModManifest, () => this.Helper.Translation.Get("config.section.general"));
            configMenu.AddBoolOption(this.ModManifest, () => this.Config.DebugMode, v => this.Config.DebugMode = v,
                () => this.Helper.Translation.Get("config.debug.name"), () => this.Helper.Translation.Get("config.debug.tooltip"));
            configMenu.AddBoolOption(this.ModManifest, () => this.Config.UseAdaptiveSpeed, v => this.Config.UseAdaptiveSpeed = v,
                () => this.Helper.Translation.Get("config.adaptive.name"), () => this.Helper.Translation.Get("config.adaptive.tooltip"));

            // Constant
            configMenu.AddSectionTitle(this.ModManifest, () => this.Helper.Translation.Get("config.section.constant"));
            AddSpeedSlider(configMenu, "config.constant.name", () => this.Config.ConstantSpeed, v => this.Config.ConstantSpeed = v, "config.constant.tooltip");

            // Adaptive
            configMenu.AddSectionTitle(this.ModManifest, () => this.Helper.Translation.Get("config.section.adaptive"));
            configMenu.AddParagraph(this.ModManifest, () => this.Helper.Translation.Get("config.adaptive.note"));

            AddSpeedSlider(configMenu, "config.energy.100", () => this.Config.Speed_100, v => this.Config.Speed_100 = v);
            AddSpeedSlider(configMenu, "config.energy.99_70", () => this.Config.Speed_99_to_70, v => this.Config.Speed_99_to_70 = v);
            AddSpeedSlider(configMenu, "config.energy.69_40", () => this.Config.Speed_69_to_40, v => this.Config.Speed_69_to_40 = v);
            AddSpeedSlider(configMenu, "config.energy.39_10", () => this.Config.Speed_39_to_10, v => this.Config.Speed_39_to_10 = v);
            AddSpeedSlider(configMenu, "config.energy.09_00", () => this.Config.Speed_09_to_00, v => this.Config.Speed_09_to_00 = v);
        }

        private void AddSpeedSlider(IGenericModConfigMenuApi api, string labelKey, Func<int> get, Action<int> set, string? tooltipKey = null)
        {
            api.AddNumberOption(
                mod: this.ModManifest,
                getValue: get,
                setValue: set,
                name: () => this.Helper.Translation.Get(labelKey),
                tooltip: tooltipKey != null ? () => this.Helper.Translation.Get(tooltipKey) : null,
                min: -5,
                max: 10,
                interval: 1
            );
        }
    }
}